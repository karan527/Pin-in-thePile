# Pin in the Pile (Android)

A 3D first-person game: dig through a mountain of toothpicks and find the hidden steel pin.
The game is a WebView app; the game code is `app/src/main/assets/index.html`.

## Get the APK with GitHub (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The build starts automatically on every push
   (or click **Build Android APK > Run workflow**).
3. When it finishes (about 3-5 minutes), open the run and download **PinInThePile-debug-apk** under Artifacts.
4. Unzip it, copy `app-debug.apk` to your phone and install it (allow "install unknown apps").

## Build locally
Open the folder in Android Studio and choose Build > Build APK(s).

Saves use the WebView's local storage. The Back button opens the pause menu.
